// alert("Hello Welcome to Web Launch 2020 ! This is Yien ^^ ");
// document.write("Hello Welcome to Web Launch 2020 ! This is Yien ^^ ");
// document.getElementById("change").innerHTML =
//   "Hello Welcome to Web Launch 2020 ! This is Yien ^^ ";

var surname = "Cheong";
let name = "Yien";
let birthDate = 10;

console.log(surname);
console.log(name);
console.log(birthDate);

const birthMonth = 10;
console.log(birthMonth);

let name1 = "My Name";
let age = 18;
let choice0 = true;
let firstName = null;
let lastName = undefined;

let colours = ["red", "orange", "yellow", "green", "violet"];
console.log(colours);

// console.log(colours[4]);

// colours[5]='blue';

// colours[6] = 123;
// console.log(colours);

//if and Else
// let score = 40;
// if (score >= 80) {
//   console.log("Congratulations!!!");
// } else console.log("It's ok, try harder next round.");

//Switch Case
// let choice = "A";
// switch (choice) {
//   case "A":
//     console.log("I chose A");
//     break;
//   case "B":
//     console.log("I chose B");
//     break;
//   case "C":
//     console.log("I chose C");
//     break;
//   default:
//     console.log("Please make a choice");
// }

//while loop
// let counter = 0;
// while (counter < 5) {
//   console.log("Hi");
//   counter++;
// }

//for loop
// for (let counter = 0; counter <= 5; counter++) {
//   console.log("HI");
// }

//Object
// let person = {
//   name: "Cheong",
//   age: 18,
//   dob: "01/01/2002",
// };

// for (let properties in person) {
//   console.log(properties);
// }

// for (let properties in person) {
//   console.log(properties, person.properties);
// }

// const colours2 = [
//   "red",
//   "orange",
//   "yellow",
//   "green",
//   "blue",
//   "indigo",
//   "purple",
// ];

// for (let count = 0; count < colours2.length; count++) {
//   console.log(colours2[count]);
// }

//function
// function greet(name) {
//   alert("Hi, " + name);
// }
